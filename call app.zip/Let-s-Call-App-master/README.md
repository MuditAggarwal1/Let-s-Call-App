# Let-s-Call-App
 
It's calling app through calling API built in native Java.
